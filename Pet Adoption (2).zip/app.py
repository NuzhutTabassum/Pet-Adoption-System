from flask import * 
import sqlite3

app = Flask(__name__)

# Configure SQLite database
#conn = sqlite3.connect('database.db')

def connect_db():
    c = sqlite3.connect("pet_adoption.db").cursor()
    c.execute("CREATE TABLE IF NOT EXISTS SIGNUP("
              "name TEXT, phone_number INTEGER, user_type TEXT)"
              )
    c.connection.close()   
    
# Route to display the index.html template
@app.route("/")
def Adopt_your_companion():
    return render_template('index.html')

# Route to display the signup.html template
@app.route("/signup")
def sign():
    return render_template('signup.html')

# Route to handle the form submission for signup
@app.route("/signup", methods=["GET","POST"])
def signup():
    
    if request.method == "GET":
        name = request.form.get("name")
        phone_number = request.form.get("phone_number")
        password = request.form.get("password")
        user_type = request.form.get("user_type")
        
    db = sqlite3.connect("pet_adoption.db")
    c = db.cursor()
    Signup = signup(request.form["name"],
                    request.form["phone_number"],
                    request.form["user_type"]
                    )
    c.execute("INSERT INTO STUDENTS VALUES(?,?,?)",
              (name, phone_number, user_type))
    db.commit()  

 
 # Route to display the login.html template   
@app.route("/login")
def login():
    return render_template('login.html')

@app.route("/login", methods=["GET","POST"])
def process_login():
    if request.method == "POST":
        phone_number = request.form.get("phone_number")
        password = request.form.get("password")
        
    db = sqlite3.connect("pet_adoption.db")
    c = db.cursor()
    Login = process_login(request.form["phone_number"],
                    request.form["password"],
                    )
    c.execute("INSERT INTO STUDENTS VALUES(?,?)",
              (phone_number, password))
    db.commit()

    if user_type:    
        user_type = user_type[1] 
        if user_type == "Admin":  
            return redirect(url_for('admin_dashboard.html'))
            
        elif user_type == "User":
            return redirect(url_for('user_dashboard.html'))
            
        elif user_type == "Donor":
            return redirect(url_for('donor_dashboard.html'))
            
        elif user_type == "Volunteer":
            return redirect(url_for('volunteer_dashboard.html'))
            
        else:
            return redirect(url_for('login.html'))

@app.route('/')
def user_dashboard():
    return render_template('user_dashboard.html')

@app.route('/')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/')
def donor_dashboard():
    return render_template('donor_dashboard.html')

@app.route('/')
def volunteer_dashboard():
    return render_template('volunteer_dashboard.html')



@app.route('/')
def logout():
    return redirect(url_for('index.html'))

    
@app.route("/pet_registration")
def pet_register():
    return render_template('pet_registration.html')
    
@app.route("/", methods=["GET", "POST"])
def pet_registration():
    if request.method == "POST":
        name = request.form.get("Name")
        category = request.form.get("Category")
        age = request.form.get("Age")
        weight = request.form.get("Weight")
        rescuebackground = request.form.get("Rescuebackground")

    db = sqlite3.connect("pet_adoption.db")
    c = db.cursor()
    Register = pet_registration(request.form["Name"],
                               request.form["Category"],
                               request.form["Age"],
                               request.form["Weight"],
                               request.form["Rescuebackground"],
                               )
    c.execute("INSERT INTO STUDENTS VALUES(?,?,?,?)",
              (name, category, age, weight, rescuebackground))
    db.commit()
    
 
    
@app.route('/pet_registration', methods=['GET'])
def getPets():
    c = sqlite3.connect("pet_adoption.db").cursor()
    c.execute("SELECT * FROM PET_REGISTRATION")
    data = c.fetchall()
    print(data)
    return data
    
    
@app.route("/request")
def request():
    return render_template('request.html')


@app.route("/request", methods=["GET", "POST"])
def pet_request():
    if request.method == "POST":
        name = request.form.get("Name")
        phone_number = request.form.get("Phone_number")
        description = request.form.get("Description")
        pet_type = request.form.get("Pet_type")
        pet_name = request.form.get("Pet_name")
        age = request.form.get("Age")
        gender = request.form.get("Gender")
        breed = request.form.get("Breed")
        status = request.form.get("Status")
        
        return redirect(url_for('appointment.html'))

        db = sqlite3.connect("pet_adoption.db")
        c = db.cursor()
        Request = pet_request(request.form["Name"],
                              request.form["Phone_number"],
                              request.form["Desciption"],
                              request.form["Pet_type"],
                              request.form["Pet_name"],
                              request.form["Age"],
                              request.form["Gender"],
                              request.form["Breed"],
                              request.form["Status"],S
                              )
        c.execute("INSERT INTO STUDENTS VALUES(?,?,?,?,?,?,?,?,?)",
        (name, phone_number, description, pet_type, pet_name, age, gender, breed, status))
                  
        db.commit()
        
    
    
@app.route('/medical_info')
def medical_info():
    return render_template('medical_info.html')    


@app.route('/accept')
def accept_pet():
    return render_template('accept.html')
 
@app.route('/appointment')
def appointment():
    return render_template('appointment.html')

@app.route('/delete')
def delete_pet():
    return render_template('delete.html')

@app.route('/request')
def request_pet():
    return render_template('request.html') 

 
    
@app.route('/payment', methods=['GET', 'POST'])
def donation():
    if request.method == 'POST':
        amount = float(request.form['amount'])
        payment_type = request.form['paymentType']
        organization_type = request.form['organizationType']
        return render_template('donation.html', confirmed_amount=amount)
    return render_template('donation.html')

        
    db = sqlite3.connect("pet_adoption.db")
    c = db.cursor()
    payment = donation(request.form["amount"],
                       request.form["paymentType"],
                       request.form["organizationType"],
                       )
    c.execute("INSERT INTO STUDENTS VALUES(?,?,?)",
            (amount, payment_type, organization_type))
    db.commit()


    
if __name__ == "__main__":
    app.run(debug=True)